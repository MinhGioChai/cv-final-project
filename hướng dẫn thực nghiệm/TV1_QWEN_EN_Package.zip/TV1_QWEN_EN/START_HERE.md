# TV1

Giải nén master VLM_ENVI_Main_Inference_Team_v1.zip có SHA256 `29f7b3326df239df1f2bea8286ea38c4cd12ed11f0438cae861b3b998d0689f5`.
Mở members/TV1_QWEN_EN/START_TV1.md trong master; dùng cùng project/shared/main_assets.
ZIP này không có source/assets riêng; không thay thế master, không phải Phase-B release.
